// ==UserScript==
// @name         Novel Replace Name Tool
// @namespace
// @updateURL
// @downloadURL
// @version      0.0.0
// @description  Có làm mới có ăn
// @author       iChickn
// @match        https://truyen.tangthuvien.vn/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=tangthuvien.vn
// @grant        GM_addStyle
// @run-at       document-end
// ==/UserScript==

GM_addStyle(`
.position-relative {
  position: relative;
}

.position-relative .form-control {
    padding-right: 23px;
}

textarea {
  resize: none;
}

.close-icon {
  position: absolute;
  top: 10px;
  right: 10px;
}

/* Replace box */
#replace-box {
  width: 250px;
  display: block;
  position: absolute;
  padding: 5px 15px 15px 15px;
  border-color: #e5e5e5 #eee #eee;
  border-style: solid;
  border-width: 1px 0;
  box-shadow: inset 0 3px 6px rgba(0, 0, 0, .05);
  background-color: #2798A1;
  border-radius: 6px;
  z-index: 10;
}

.main-box .row:nth-child(n+3) {
  margin-top: 5px;
}

.case-sensitive {
  position: absolute;
  right: 23px;
  top: 8px;
  cursor: pointer;
}

/* Setting box */
#setting-box {
  width: 311px;
  display: block;
  position: fixed;
  right: 0;
  top: 0;
  padding: 5px 15px 15px 15px;
  border-color: #e5e5e5 #eee #eee;
  border-style: solid;
  border-width: 1px 0;
  box-shadow: inset 0 3px 6px rgba(0, 0, 0, .05);
  background-color: #2798A1;
  border-radius: 6px;
  z-index: 9999;
}
`);

(function ($) {
  $.localStorage = function (key, value) {
    let result;
    if (localStorage == null) {
      return alert("Local storage not supported!");
    } else {
      try {
        if (typeof value != "undefined") {
          localStorage.setItem(key, value);
          result = value;
        } else {
          result =
            value === null
              ? localStorage.removeItem(key)
              : localStorage.getItem(key);
        }
        return result;
      } catch (err) {
        if (/QUOTA_EXCEEDED_ERR/.test(err)) {
          alert("Unable to store local data. Are you using Private Browsing?");
        } else {
          throw err;
        }
      }
    }
  };
})(jQuery);

let main_box = document.createElement('div');
main_box.innerHTML = `
<div class="main-box">
  <!-- Replace Box -->
  <div id="replace-box" style="display: none;" tabindex="-1">
    <div class="row">
        <div class="col-md-12 position-relative">
            <h4>Thay tên</h4>
            <i class="fa fa-fw fa-times close-icon" aria-hidden="true"></i>
        </div>
    </div>
    <div class="row">
      <div class="col-md-12 position-relative">
        <input type="text" class="form-control" id="search-value" placeholder="Nhập tên" tabindex="1">
        <p class="case-sensitive" href="#" data="1" data-toggle="tooltip" title="Phân biệt hoa thường">
          <svg color="gray" xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 16 16">
            <path fill="currentColor" d="M8.854 11.702h-1l-.816-2.159H3.772l-.768 2.16H2L4.954 4h.935l2.965 7.702Zm-2.111-2.97L5.534 5.45a3.142 3.142 0 0 1-.118-.515h-.021c-.036.218-.077.39-.124.515L4.073 8.732h2.67Zm7.013 2.97h-.88v-.86h-.022c-.383.66-.947.99-1.692.99c-.548 0-.978-.146-1.29-.436c-.307-.29-.461-.675-.461-1.155c0-1.027.605-1.625 1.815-1.794l1.65-.23c0-.935-.379-1.403-1.134-1.403c-.663 0-1.26.226-1.794.677V6.59c.54-.344 1.164-.516 1.87-.516c1.292 0 1.938.684 1.938 2.052v3.577Zm-.88-2.782l-1.327.183c-.409.057-.717.159-.924.306c-.208.143-.312.399-.312.768c0 .268.095.489.285.66c.193.169.45.253.768.253a1.41 1.41 0 0 0 1.08-.457c.286-.308.43-.696.43-1.165V8.92Z">
            </path>
          </svg>
        </p>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <input type="text" class="form-control" id="replace-value" placeholder="Nhập tên cần thay thế" tabindex="2">
      </div>
    </div>
    <div class="row">
      <div class="col-md-6">
        <button id="setting-btn" class="btn btn-default btn-block" type="button" tabindex="3">
          <i class="fa fa-fw fa-cog" aria-hidden="true"></i>Quản lý</button>
      </div>
      <div class="col-md-6">
        <button id="replace-btn" class="btn btn-default btn-block" type="button" tabindex="4">
          <i class="fa fa-fw fa-plus" aria-hidden="true"></i>Thay thế</button>
      </div>
    </div>
  </div>

  <!-- Setting Box -->
  <div id="setting-box" style="display: none;">
    <div class="row">
        <div class="col-md-12 position-relative">
              <h4>Danh sách tên đã lưu</h4>
            <i class="fa fa-fw fa-times close-icon" aria-hidden="true"></i>
        </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <textarea id="name-list" class="form-control" rows="10"></textarea>
      </div>
    </div>
    <div class="row">
      <div class="col-md-4">
        <button id="download-btn" class="btn btn-default btn-block" type="button">
          <i class="fa fa-fw fa-cloud-download" aria-hidden="true"></i>Tải xuống</button>
      </div>
      <div class="col-md-4">
        <button id="upload-btn" class="btn btn-default btn-block" type="button">
          <i class="fa fa-fw fa-cloud-upload" aria-hidden="true"></i>Tải lên</button>
      </div>
      <div class="col-md-4">
        <button id="save-btn" class="btn btn-default btn-block" type="button">
          <i class="fa fa-fw fa-floppy-o" aria-hidden="true"></i>Lưu lại</button>
      </div>
    </div>
  </div>
</div>
`;

document.body.appendChild(main_box);

let selectedText = "";
const $ = jQuery;

const getSelectionText = () => {
  selectedText = "";
  let activeEl = document.activeElement;
  let activeElTagName = activeEl ? activeEl.tagName.toLowerCase() : null;
  if (activeElTagName === "body" && window.getSelection) {
    selectedText = window.getSelection().toString().trim();
  }
}

document.onselectionchange = getSelectionText;

$(".chapter-c-content").on("mouseup", function (event) {
  if (selectedText) {
    $("#search-value").val(selectedText);
    $("#replace-box").css({ left: event.pageX, top: event.pageY + 10 }).toggle();
    $("#replace-value").focus();
  }
});

const CASE_SENSITIVE = [
  {
    data: 1,
    color: "gray",
    title: "Phân biệt hoa thường"
  },
  {
    data: 0,
    color: "red",
    title: "Không phân biệt hoa thường"
  }
];

const SITE_SETTINGS = {
  "truyen.tangthuvien.vn": {
    path_regex: /([\/][a-z]{6}-[0-9]{1,5})+$/g,
    story_id_selector: "[name='story_id']"
  }
};
const SPLIT_LINE_CHAR = "•/•";
const NEW_LINE_CHAR = "\n";
const SEPARATE_CHAR = "•";

let story_id = $(SITE_SETTINGS[location.hostname].story_id_selector).val();
let capture;
let tabbable;

const init = () => {
  setNames(loadNames());
  replaceNames();
};

const getNames = () => {
  return $("#name-list").val().trim();
};

const setNames = (names) => {
  $("#name-list").val(names);
};

const loadNames = () => {
  let _name_list = $.localStorage(story_id) ?? "";
  if (_name_list && _name_list.length) {
    _name_list = unescape(_name_list)
    _name_list = _name_list.split(SPLIT_LINE_CHAR).join(NEW_LINE_CHAR)
  }
  return _name_list;
}

const saveNames = () => {
  let _nl = getNames();
  _nl = _nl.split(NEW_LINE_CHAR).map(line => line.split(SEPARATE_CHAR).map(txt => escape(txt)).join(SEPARATE_CHAR)).join(SPLIT_LINE_CHAR);

  $.localStorage(story_id, _nl);
  replaceNames();
};

const sortNames = () => {
  let _name_list = getNames().split(NEW_LINE_CHAR);
  _name_list = _name_list.sort(
    (a, b) => a.split(SEPARATE_CHAR)[0].length - b.split(SEPARATE_CHAR)[0].length
  );
  setNames(_name_list.join(NEW_LINE_CHAR));
  saveNames();
};

const replaceNames = () => {
  let _name_list = getNames().split(NEW_LINE_CHAR);
  let _num_names = _name_list.length;
  let txtWalker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
    acceptNode: function (node) {
      //-- Skip whitespace-only nodes
      if (node.nodeValue.trim()) return NodeFilter.FILTER_ACCEPT;
      return NodeFilter.FILTER_SKIP;
    }
  }, false);
  let txtNode = null;
  while (txtNode = txtWalker.nextNode()) {
    let oldTxt = txtNode.nodeValue;
    for (let idx = 0; idx < _num_names; idx++) {
      let [sensitive, searchValue, replaceValue] = _name_list[idx].split(SEPARATE_CHAR)
      oldTxt = oldTxt.replace(new RegExp(searchValue, !sensitive ? "g" : "gi"), replaceValue);
    }
    txtNode.nodeValue = oldTxt;
  }
}

const handleKeydown = (event) => {
  if (event.keyCode === 39 || event.keyCode === 37) {
    event.preventDefault();
    event.stopPropagation();
    return;
  }
  if (event.key.toLowerCase() !== "tab") {
    return;
  }

  let target = $(event.target);

  if (event.shiftKey) {
    if (target.is(capture) || target.is(tabbable.first())) {
      event.preventDefault();
      tabbable.last().focus();
    }
  } else {
    if (target.is(tabbable.last())) {
      event.preventDefault();
      tabbable.first().focus();
    }
  }
}

$("#replace-box, #setting-box")
  .on("focusin", function () {
    capture = $(this);
    tabbable = capture.find("input, textarea, button");
  })
  .on("keydown", handleKeydown);

$(".case-sensitive").on("click", function () {
  const _sensitive = $(this).attr("data");
  const { data, color, title } = CASE_SENSITIVE[_sensitive];
  $(this).children("svg").attr({ color });
  $(this).attr({ data, title });
});

$("#setting-btn").on("click", function () {
  $("#setting-box").toggle();
});

$("#replace-btn").on("click", function () {
  $("#replace-box").toggle();
  let _s = $("#search-value").val().trim();
  let _r = $("#replace-value").val().trim();
  let _cs = $(".case-sensitive").attr("data");

  if (_s && _r) {
    let _new_name = `${NEW_LINE_CHAR}${_cs}${SEPARATE_CHAR}${_s}${SEPARATE_CHAR}${_r}`;
    let _name_list = getNames();
    _name_list += _new_name;
    setNames(_name_list);
    sortNames();
  }
});

$("#save-btn").on("click", saveNames);

$("#download-btn").on("click", function () {
  alert("Download");
});

$("#upload-btn").on("click", function () {
  alert("Upload");
});

$(".close-icon").on("click", function () {
  $(this).parentsUntil(".main-box").last().toggle();
});

init();
